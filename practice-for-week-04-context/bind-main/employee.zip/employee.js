class Employee {
    constructor(name, occupation) {
        this.name = name;
        this.occupation = occupation;
    }

  sayName() {
      console.log(`${this.name} says Hello`);
  }

  sayOccupation(){
    console.log(`${this.name} is a ${this.occupation}`);
  }
};

module.exports = Employee;
