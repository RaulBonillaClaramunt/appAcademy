# Design Notes
Instagram's landing page is pretty clean and only allows you to signup or login
you know what instagram is so they won't tell
a rollup of pictures flow through a phone screen as in real life
cute, vague, fun pictures as 99% in real life

Github displays a dark bacjground as it is meant to be used by programmers
There's various callings to action: signup + start free enterprise trial + discount banner
If you scroll there is an exhaustive explanation of everything you can achieve with the platform

Reddit ispacked with info straight away as it is supposed to be a go-to place for knowing what is going on: Their leit-motif is "Dive into anything". The default background is also dark as it is meant to be used by "nerddy" users. Basic functionalities on the left side, much like a dashboard panel.

Paul Graham is a founder, one of the fathers of internet as we know it and so he is reaaly edgy on his take. He doesn't need to appeal to his audience with a fancy design hence the contrary: pure simple HTML no CSS no nothing; Love it! He is what Sed Godin calls "the purple cow". Top. Not replicable.

Supreme is an edgy clothe company using a black background landing page where their logo is red and white so evrything is quite edgy. Once you navigate through the website background is white and colourful clothes (parts of them) are on display, so it is visually super apealing. Minimalism vs anti-minimalism in the sharing the same screen. I don't like their clothes but love their website.
